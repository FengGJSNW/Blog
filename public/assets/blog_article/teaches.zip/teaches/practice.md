---
title: 用于练习撰写Markdown
published: 2026-01-06
description: 练习撰写Markdown
tags: [示例]
category: 文章示例
draft: false
---

# title 1
## title 2
### title 3

> code
>> code


### 方案三：如果你在用特定的渲染引擎（如自定义 CSS）

如果你能接触到你网站的 CSS 文件，你只需要写一行 CSS，以后你所有的 ` ```c ` 就会**自动**在顶部出现一个 "C" 字样，你完全不需要修改 Markdown 源码。

**将这段代码加入你的 CSS：**

```css
/* 当代码块类名为 language-c 时，在上方生成文字 */
pre[class*="language-c"]::before {
    content: "C Source Code";
    display: block;
    background: #2d4035;
    color: #78a083;
    font-size: 10px;
    padding: 2px 10px;
    border-bottom: 1px solid #3d5a48;
}